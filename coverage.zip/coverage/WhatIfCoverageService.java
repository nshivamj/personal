import com.portfolio.coverage.*;

@Service
public class WhatIfCoverageService {

    @Autowired private BaseEntityItemFetcher baseItemFetcher;
    @Autowired private EntityItemEnricherFactory enricherFactory;
    @Autowired private CoverageCalculationService coverageCalculator;
    @Autowired private CoverageAggregator aggregator;

    public List<CoverageSummary> evaluateWhatIf(ScenarioContext context, LocalDate period) {
        List<BaseEntityItem> baseItems = baseItemFetcher.fetchBaseItems(context); // handles removals/additions

        // Group by entity type for batch enrichment
        Map<String, List<BaseEntityItem>> grouped = baseItems.stream()
                .collect(Collectors.groupingBy(BaseEntityItem::getEntityType));

        List<EntityItem> enrichedAll = new ArrayList<>();
        for (Map.Entry<String, List<BaseEntityItem>> entry : grouped.entrySet()) {
            EntityItemEnricher enricher = enricherFactory.getEnricher(entry.getKey());
            List<EntityItem> enriched = enricher.enrich(entry.getValue(), context);
            enrichedAll.addAll(enriched);
        }

        List<CoverageResult> itemResults = coverageCalculator.calculate(enrichedAll, period);
        return aggregator.aggregate(itemResults);
    }
}
