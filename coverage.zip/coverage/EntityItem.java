package com.portfolio.coverage;

public class EntityItem extends BaseEntityItem {
    private int windowSize;
    private boolean isValid;
    private String ouRating;
    private String entityResidualRating;
    private List<String> coverageMappings;
    // Any enriched metadata added via enricher
}


