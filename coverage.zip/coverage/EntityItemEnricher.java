package com.portfolio.coverage;

public interface EntityItemEnricher {
    void enrich(List<EntityItem> items, Map<String, Object> scenarioContext);
    String getEntityType();
}


