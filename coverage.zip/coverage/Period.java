package com.portfolio.coverage;

public class Period {
    private LocalDate startDate;
    private LocalDate endDate;

    // For single period: startDate == endDate
    public boolean withinWindow(Window window) {
        return window.getStart().compareTo(endDate) <= 0 &&
                window.getEnd().compareTo(startDate) >= 0;
    }

    public static Period of(LocalDate singleDate) {
        return new Period(singleDate, singleDate);
    }

    public static Period of(LocalDate start, LocalDate end) {
        return new Period(start, end);
    }
}



