package com.portfolio.coverage;


public class OURCCoverageAggregator implements CoverageAggregator {

    @Override
    public boolean supports(EntityType entityType) {
        return EntityType.OURC.equals(entityType);
    }

    @Override
    public CoverageSummary aggregate(String entityId, EntityType entityType, LocalDate period, List<CoverageResult> results) {
        boolean atLeastOneCovered = results.stream().anyMatch(CoverageResult::isCovered);

        CoverageSummary summary = new CoverageSummary();
        summary.setEntityId(entityId);
        summary.setEntityType(entityType.name());
        summary.setPeriod(period);
        summary.setEntityCovered(atLeastOneCovered);
        summary.setItemCoverageResults(results);

        return summary;
    }
}









