package com.portfolio.coverage;

public interface CoverageItemRepository {
    Map<String, Object> getItemAttributes(String itemId, ScenarioContext context);
}




