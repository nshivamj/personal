package com.portfolio.coverage;

@Component
public class ScenarioEntityItemBuilder {

    @Autowired private EntityItemFetcherService itemFetcher;
    @Autowired private ProjectChangeApplier projectChangeApplier;
    @Autowired private MappingChangeApplier mappingChangeApplier;
    @Autowired private EntityRatingChangeApplier ratingChangeApplier;

    public List<EntityItem> build(WhatIfScenarioRequest request) {
        Set<String> projectIds = request.getProjectChanges().stream()
                .map(ProjectChangeDto::getProjectId).collect(Collectors.toSet());

        // 1. Fetch base entity items
        List<EntityItem> baseItems = itemFetcher.getByProjectIds(projectIds);

        // 2. Apply new mappings (add new or remove missing)
        List<EntityItem> mappedItems = mappingChangeApplier.apply(baseItems, request.getValidEntityItemsByProject());

        // 3. Apply project attribute changes
        List<EntityItem> updatedItems = projectChangeApplier.apply(mappedItems, request.getProjectChanges());

        // 4. Apply new ratings
        return ratingChangeApplier.apply(updatedItems, request.getRatingChanges());
    }
}


