package com.portfolio.coverage;


public class EntityItemBuilderService2 {

    @Autowired private CoverageEntityRepository entityRepo;
    @Autowired private CoverageItemRepository itemRepo;
    @Autowired private CoverageMappingRepository mappingRepo;

    public List<EntityItem> buildBaseItems(List<Long> entityIds, List<Long> itemIds) {
        List<CoverageMapping> mappings = mappingRepo.findByEntityOrItemIds(entityIds, itemIds);
        Map<Long, CoverageEntity> entities = entityRepo.findAllAsMap();
        Map<Long, CoverageItem> items = itemRepo.findAllAsMap();

        List<EntityItem> entityItems = new ArrayList<>();

        for (CoverageMapping mapping : mappings) {
            CoverageEntity entity = entities.get(mapping.getEntityId());
            CoverageItem item = items.get(mapping.getItemId());

            EntityItem ei = new EntityItem();
            ei.setEntityId(entity.getId());
            ei.setItemId(item.getId());
            ei.setEntityType(entity.getEntityType());
            ei.setYear(mapping.getYear());
            ei.setQuarter(mapping.getQuarter());

            // Copy attributes from entity, item, mapping
            ei.getAttributes().putAll(entity.getAttributes());
            ei.getAttributes().putAll(item.getAttributes());
            ei.getAttributes().putAll(mapping.getAttributes());

            entityItems.add(ei);
        }

        return entityItems;
    }

    public List<EntityItem> buildWithWhatIfChanges(
            ScenarioContext scenarioContext
    ) {
        // 1. Clone base data
        // 2. Apply project attribute overrides from scenarioContext.projectChanges
        // 3. Apply rating updates from scenarioContext.ratingChanges
        // 4. Remove/add mappings from scenarioContext.mappingChanges

        return buildBaseItemsWithScenarioMerged(scenarioContext);
    }
}


