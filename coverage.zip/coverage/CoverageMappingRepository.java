package com.portfolio.coverage;

public interface CoverageMappingRepository {
    List<CoverageMapping> fetchAllActiveMappings(); // or filtered by scenario
}





