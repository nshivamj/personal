package com.portfolio.coverage;

public interface CoverageEntityRepository {
    Optional<OUEntity> getOUEntity(String entityId);
    Optional<OURCEntity> getOURCEntity(String entityId);
}


