package com.portfolio.coverage;


public class EntityItemService2 {

    @Autowired private EntityItemEnricherFactory enricherFactory;

    public List<EntityItem> enrich(List<EntityItem> items, ScenarioContext context) {
        Map<String, List<EntityItem>> byType = items.stream()
                .collect(Collectors.groupingBy(EntityItem::getEntityType));

        List<EntityItem> enriched = new ArrayList<>();

        for (Map.Entry<String, List<EntityItem>> entry : byType.entrySet()) {
            EntityItemEnricher enricher = enricherFactory.getEnricher(entry.getKey());
            enriched.addAll(enricher.enrich(entry.getValue(), context));
        }

        return enriched;
    }
}


