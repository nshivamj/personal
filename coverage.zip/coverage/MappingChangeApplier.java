package com.portfolio.coverage;

@Component
public class MappingChangeApplier {

    @Autowired private EntityItemRepository itemRepo;

    public List<EntityItem> apply(List<EntityItem> baseItems, Map<String, List<String>> validEntityItemsByProjectId) {
        Set<String> baseKeys = baseItems.stream()
                .map(item -> item.getProjectId() + "|" + item.getEntityId())
                .collect(Collectors.toSet());

        List<EntityItem> result = new ArrayList<>(baseItems);

        // Add new entity items for new mappings
        for (Map.Entry<String, List<String>> entry : validEntityItemsByProjectId.entrySet()) {
            String projectId = entry.getKey();
            for (String entityId : entry.getValue()) {
                String key = projectId + "|" + entityId;
                if (!baseKeys.contains(key)) {
                    // Create new EntityItem for this mapping
                    EntityItem newItem = itemRepo.buildEmptyEntityItem(projectId, entityId);
                    result.add(newItem);
                }
            }
        }

        return result;
    }
}



