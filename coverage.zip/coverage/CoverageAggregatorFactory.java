package com.portfolio.coverage;

@Component
public class CoverageAggregatorFactory {

    private final List<CoverageAggregator> aggregators;

    @Autowired
    public CoverageAggregatorFactory(List<CoverageAggregator> aggregators) {
        this.aggregators = aggregators;
    }

    public CoverageAggregator getAggregator(EntityType entityType) {
        return aggregators.stream()
                .filter(agg -> agg.supports(entityType))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No aggregator for type " + entityType));
    }
}





