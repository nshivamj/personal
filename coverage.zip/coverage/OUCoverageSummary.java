package com.portfolio.coverage;

public class OUCoverageSummary {
    private String ouId;
    private String entityType;
    private LocalDate period;
    private boolean ouCovered;
    private List<CoverageSummary> entitySummaries;

    // getters and setters
}





