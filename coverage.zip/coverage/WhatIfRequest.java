package com.portfolio.coverage;

public class WhatIfRequest {
    private Period period;
    private ScenarioData scenario;
}
