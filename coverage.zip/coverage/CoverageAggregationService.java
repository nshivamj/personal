package com.portfolio.coverage;


@Service
public class CoverageAggregationService {

    @Autowired
    private CoverageAggregatorFactory aggregatorFactory;

    public CoverageSummary aggregatePerEntity(String entityId, EntityType entityType, LocalDate period, List<CoverageResult> results) {
        CoverageAggregator aggregator = aggregatorFactory.getAggregator(entityType);
        return aggregator.aggregate(entityId, entityType, period, results);
    }
}



