package com.portfolio.coverage;

@Service
public class OUAggregationService {

    private final OUAggregatorFactory aggregatorFactory;

    @Autowired
    public OUAggregationService(OUAggregatorFactory aggregatorFactory) {
        this.aggregatorFactory = aggregatorFactory;
    }

    public OUCoverageSummary aggregateOuLevel(String ouId, EntityType entityType, LocalDate period, List<CoverageSummary> entitySummaries) {
        OUAggregator aggregator = aggregatorFactory.getAggregator(entityType);
        return aggregator.aggregateOuCoverage(ouId, entityType, period, entitySummaries);
    }
}





