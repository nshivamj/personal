package com.portfolio.coverage;

@Service
public class CoverageEvaluationService {

    @Autowired private EntityItemProvider entityItemProvider;
    @Autowired private EntityItemEnricher enricher;
    @Autowired private CoverageCalculationService calculator;
    @Autowired private CoverageAggregator aggregator;
    @Autowired private OUAggregationService ouAggregationService;

    public List<OUCoverageSummary> evaluateCoverage(CoverageRequest request) {
        List<BaseEntityItem> items = entityItemProvider.getItemsForOus(request.getOuIds(), request.getPeriod());

        List<BaseEntityItem> finalItems = applyWhatIfIfNeeded(items, request);

        List<EntityItem> enriched = enricher.enrichAll(finalItems, request.getPeriod(), request.getScenario());

        List<CoverageResult> results = calculator.calculate(enriched, request.getPeriod());

        List<CoverageSummary> summaries = aggregator.aggregateEntityLevel(results);

        // Group summaries by OU ID and Entity Type
        Map<String, Map<EntityType, List<CoverageSummary>>> grouped = groupByOuAndType(summaries);

        // Run OU-level aggregation
        List<OUCoverageSummary> ouSummaries = new ArrayList<>();

        for (Map.Entry<String, Map<EntityType, List<CoverageSummary>>> ouEntry : grouped.entrySet()) {
            String ouId = ouEntry.getKey();
            Map<EntityType, List<CoverageSummary>> summariesPerType = ouEntry.getValue();

            for (Map.Entry<EntityType, List<CoverageSummary>> entityTypeEntry : summariesPerType.entrySet()) {
                EntityType entityType = entityTypeEntry.getKey();
                List<CoverageSummary> entitySummaries = entityTypeEntry.getValue();

                OUCoverageSummary ouSummary = ouAggregationService.aggregateOuLevel(
                        ouId, entityType, request.getPeriod(), entitySummaries
                );
                ouSummaries.add(ouSummary);
            }
        }

        return ouSummaries;
    }

    private List<BaseEntityItem> applyWhatIfIfNeeded(List<BaseEntityItem> items, CoverageRequest request) {
        if (request.getScenario() == null) return items;

        // Apply What-If scenario changes to generate updated item list
        return ScenarioItemTransformer.applyScenario(items, request.getScenario());
    }

    private Map<String, Map<EntityType, List<CoverageSummary>>> groupByOuAndType(List<CoverageSummary> summaries) {
        return summaries.stream()
                .collect(Collectors.groupingBy(
                        CoverageSummary::getOuId,
                        Collectors.groupingBy(CoverageSummary::getEntityType)
                ));
    }
}


