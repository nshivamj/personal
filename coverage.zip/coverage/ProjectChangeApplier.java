package com.portfolio.coverage;

@Component
public class ProjectChangeApplier {

    public List<EntityItem> apply(List<EntityItem> entityItems, List<ProjectChangeDto> projectChanges) {
        Map<String, Map<String, Object>> changesMap = projectChanges.stream()
                .collect(Collectors.toMap(ProjectChangeDto::getProjectId, ProjectChangeDto::getUpdatedAttributes));

        for (EntityItem item : entityItems) {
            if (changesMap.containsKey(item.getItemCode())) {
                Map<String, Object> newAttributes = changesMap.get(item.getItemCode());
                newAttributes.forEach((key, value) -> item.getAttributes().put(key, value)); // assumes mutable attributes
            }
        }

        return entityItems;
    }
}


