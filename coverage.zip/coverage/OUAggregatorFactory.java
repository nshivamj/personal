package com.portfolio.coverage;

@Component
public class OUAggregatorFactory {

    private final List<OUAggregator> ouAggregators;

    @Autowired
    public OUAggregatorFactory(List<OUAggregator> ouAggregators) {
        this.ouAggregators = ouAggregators;
    }

    public OUAggregator getAggregator(EntityType entityType) {
        return ouAggregators.stream()
                .filter(agg -> agg.supports(entityType))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No OU aggregator for type: " + entityType));
    }
}





