package com.portfolio.coverage;

public class CoverageService {
    @Autowired private EntityItemRepository itemRepo;
    @Autowired private EntityItemService itemService;
    @Autowired private CoverageCalculationService calcService;

    public List<CoverageResult> getCoverage() {
        List<EntityItem> base = itemRepo.findAllBase();
        List<EntityItem> enriched = itemService.getAndEnrichItems(base, new ScenarioContext());
        return calcService.calculate(enriched);
    }
}




