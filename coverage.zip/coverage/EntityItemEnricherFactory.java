package com.portfolio.coverage;

@Component
public class EntityItemEnricherFactory {
    private final Map<String, EntityItemEnricher> enricherMap;

    @Autowired
    public EntityItemEnricherFactory(List<EntityItemEnricher> enrichers) {
        enricherMap = enrichers.stream().collect(Collectors.toMap(EntityItemEnricher::getEntityType, e -> e));
    }

    public EntityItemEnricher getEnricher(String entityType) {
        return enricherMap.get(entityType);
    }
}
