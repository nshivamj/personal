package com.portfolio.coverage;

public class CoverageRequest {
    private Period period; // can be single (as-of) or range (window)
    private List<Long> entityIds;
}


