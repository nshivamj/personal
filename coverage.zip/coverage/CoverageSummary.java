package com.portfolio.coverage;

public class CoverageSummary {
    private String entityId;
    private String entityType;
    private LocalDate period;
    private boolean isEntityCovered;
    private List<CoverageResult> itemCoverageResults;

    // Constructors, Getters, Setters
}


