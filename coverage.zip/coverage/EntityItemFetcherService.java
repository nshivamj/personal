package com.portfolio.coverage;

@Service
public class EntityItemFetcherService {

    @Autowired private EntityItemRepository itemRepo;

    public List<EntityItem> getByProjectIds(Set<String> projectIds) {
        return itemRepo.findByProjectIds(projectIds);
    }

    public List<EntityItem> getByEntityIds(Set<String> entityIds) {
        return itemRepo.findByEntityIds(entityIds);
    }

    public List<EntityItem> getByType(EntityType type) {
        return itemRepo.findByType(type);
    }

    public Optional<EntityItem> getByProjectAndEntity(String projectId, String entityId) {
        return itemRepo.findByProjectAndEntity(projectId, entityId);
    }
}


