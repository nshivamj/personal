public class NoOpAggregator implements CoverageAggregator {

    @Override
    public boolean supports(EntityType entityType) {
        return EntityType.OUBP.equals(entityType); // Or use as default fallback
    }

    @Override
    public CoverageSummary aggregate(String entityId, EntityType entityType, LocalDate period, List<CoverageResult> results) {
        // No aggregation — treat individual item result as entity result (optional logic)
        boolean atLeastOneCovered = results.stream().anyMatch(CoverageResult::isCovered);

        CoverageSummary summary = new CoverageSummary();
        summary.setEntityId(entityId);
        summary.setEntityType(entityType.name());
        summary.setPeriod(period);
        summary.setEntityCovered(atLeastOneCovered);
        summary.setItemCoverageResults(results);

        return summary;
    }
}