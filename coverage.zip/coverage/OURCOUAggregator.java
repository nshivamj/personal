package com.portfolio.coverage;

public class OURCOUAggregator implements OUAggregator {

    @Override
    public boolean supports(EntityType entityType) {
        return EntityType.OURC.equals(entityType);
    }

    @Override
    public OUCoverageSummary aggregateOuCoverage(String ouId, EntityType entityType, LocalDate period, List<CoverageSummary> entitySummaries) {
        boolean ouCovered = entitySummaries.stream().anyMatch(CoverageSummary::isEntityCovered);

        OUCoverageSummary summary = new OUCoverageSummary();
        summary.setOuId(ouId);
        summary.setEntityType(entityType.name());
        summary.setPeriod(period);
        summary.setOuCovered(ouCovered);
        summary.setEntitySummaries(entitySummaries);

        return summary;
    }
}






