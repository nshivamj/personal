package com.portfolio.coverage;

public class NewMapping {
    private String entityId;
    private String entityType;
    private String itemId;
    private LocalDate start;
    private LocalDate end;

    public NewMapping(String entityId, String entityType, String itemId, LocalDate start, LocalDate end) {
        this.entityId = entityId;
        this.entityType = entityType;
        this.itemId = itemId;
        this.start = start;
        this.end = end;
    }

    // Getters
    public String getEntityId() { return entityId; }
    public String getEntityType() { return entityType; }
    public String getItemId() { return itemId; }
    public LocalDate getStart() { return start; }
    public LocalDate getEnd() { return end; }
}








