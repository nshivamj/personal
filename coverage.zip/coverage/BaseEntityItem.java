package com.portfolio.coverage;

public class BaseEntityItem {
    private String projectId;
    private String entityId;
    private String entityType;
    private int period;
    private Map<String, Object> attributes;
    // Possibly only raw fields from SQL joins
}


