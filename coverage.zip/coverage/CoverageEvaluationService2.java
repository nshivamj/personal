package com.portfolio.coverage;

public class CoverageEvaluationService2 {

    @Autowired
    private EntityItemFetcher itemFetcher;

    @Autowired
    private ScenarioItemTransformer scenarioTransformer;

    @Autowired
    private EntityItemEnricherFactory enricherFactory;

    @Autowired
    private CoverageCalculator coverageCalculator;

    @Autowired
    private EntityCoverageAggregator entityAggregator;

    @Autowired
    private OUAggregator ouAggregator;

    public CoverageResultResponse evaluateCoverage(CoverageRequest request) {
        List<BaseEntityItem> baseItems = itemFetcher.fetchBaseItems(request);
        List<EntityItem> enrichedItems = enricherFactory.enrich(baseItems, request.getPeriod());
        List<CoverageResult> results = coverageCalculator.calculate(enrichedItems, request.getPeriod());
        return entityAggregator.aggregate(results);
    }

    public CoverageResultResponse evaluateWhatIf(WhatIfRequest request) {
        List<BaseEntityItem> baseItems = itemFetcher.fetchBaseItems(request);
        ScenarioContext scenarioContext = ScenarioContext.from(request);
        List<BaseEntityItem> transformedItems = scenarioTransformer.applyScenario(baseItems, scenarioContext);
        List<EntityItem> enrichedItems = enricherFactory.enrich(transformedItems, request.getPeriod(), scenarioContext);
        List<CoverageResult> results = coverageCalculator.calculate(enrichedItems, request.getPeriod());
        return entityAggregator.aggregate(results);
    }
}


