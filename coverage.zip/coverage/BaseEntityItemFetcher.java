package com.portfolio.coverage;


@Service
public class BaseEntityItemFetcher {

    @Autowired private CoverageMappingRepository mappingRepo;
    @Autowired private CoverageItemRepository itemRepo;
    @Autowired private CoverageEntityRepository entityRepo;

    public List<BaseEntityItem> fetchBaseItems(ScenarioContext context) {
        // Use efficient queries: fetch only entityIds or projectIds affected by scenario

        List<BaseEntityItem> baseItems = mappingRepo.fetchAllActiveMappings()
                .stream()
                .filter(mapping -> !context.isMappingRemoved(mapping.getEntityId(), mapping.getItemId()))
                .map(mapping -> {
                    Map<String, Object> itemAttributes = itemRepo.getItemAttributes(mapping.getItemId(), context);
                    return new BaseEntityItem(
                            mapping.getEntityId(),
                            mapping.getEntityType(),
                            mapping.getItemId(),
                            itemAttributes,
                            mapping.getStartDate(),
                            mapping.getEndDate()
                    );
                }).collect(Collectors.toList());

        // Add any new mappings in scenario
        for (NewMapping newMap : context.getAddedMappings()) {
            Map<String, Object> itemAttributes = itemRepo.getItemAttributes(newMap.getItemId(), context);
            baseItems.add(new BaseEntityItem(
                    newMap.getEntityId(), newMap.getEntityType(), newMap.getItemId(),
                    itemAttributes, newMap.getStart(), newMap.getEnd()
            ));
        }

        return baseItems;
    }
}


