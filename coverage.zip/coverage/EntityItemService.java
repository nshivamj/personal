package com.portfolio.coverage;

public class EntityItemService {
    @Autowired private EntityItemRepository entityItemRepo;
    @Autowired private EntityItemEnricherFactory enricherFactory;

    public List<EntityItem> getAndEnrichItems(List<EntityItem> baseItems, ScenarioContext context) {
        Map<String, List<EntityItem>> byType = baseItems.stream().collect(Collectors.groupingBy(EntityItem::getEntityType));

        List<EntityItem> enriched = new ArrayList<>();
        for (Map.Entry<String, List<EntityItem>> entry : byType.entrySet()) {
            EntityItemEnricher enricher = enricherFactory.getEnricher(entry.getKey());
            enriched.addAll(enricher.enrich(entry.getValue(), context));
        }
        return enriched;
    }
}




