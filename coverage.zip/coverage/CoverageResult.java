package com.portfolio.coverage;

public class CoverageResult {
    private String entityId;
    private String entityType;
    private String itemId;
    private LocalDate period;
    private boolean isCovered;
    private String reason; // Optional

    // Constructors, Getters, Setters
}


