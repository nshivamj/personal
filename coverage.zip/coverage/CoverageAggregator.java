public interface CoverageAggregator {
    boolean supports(EntityType entityType);
    CoverageSummary aggregate(String entityId, EntityType entityType, LocalDate period, List<CoverageResult> results);
}
