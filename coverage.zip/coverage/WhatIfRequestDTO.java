package com.portfolio.coverage;


public class WhatIfRequestDTO {
    private LocalDate period;
    private List<ProjectChangeDTO> projectChanges;
    private List<NewMapping> newMappings;
    private List<String> removedMappings;
    private Map<String, String> ratingOverrides;

    // Getters and setters
}





