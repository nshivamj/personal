package com.portfolio.coverage;

public class ScenarioContextBuilder {
    public static ScenarioContext fromRequest(WhatIfRequestDTO req) {
        ScenarioContext ctx = new ScenarioContext();

        for (ProjectChangeDTO dto : req.getProjectChanges()) {
            ctx.getProjectChanges().put(dto.getProjectId(), dto);
        }

        ctx.getRatingOverrides().putAll(req.getRatingOverrides());
        ctx.getRemovedMappings().addAll(req.getRemovedMappings());
        ctx.getAddedMappings().addAll(req.getNewMappings());

        return ctx;
    }
}






