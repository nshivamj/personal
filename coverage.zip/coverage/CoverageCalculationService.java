package com.portfolio.coverage;

public interface CoverageCalculationService {
    List<CoverageResult> calculate(List<EntityItem> enrichedItems);
}


