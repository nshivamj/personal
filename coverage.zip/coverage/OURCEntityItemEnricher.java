package com.portfolio.coverage;

@Component
public class OURCEntityItemEnricher implements EntityItemEnricher {
    @Autowired private OURCRepository ouRcRepo;
    @Autowired private OURepository ouRepo;

    @Override
    public void enrich(List<EntityItem> items, Map<String, Object> scenarioContext) {
        Map<String, Rating> baseRatings = ouRepo.getRatingsForEntities(
                items.stream().map(EntityItem::getEntityId).toList()
        );

        Map<String, Rating> ratingOverrides = extractRatingOverrides(scenarioContext);

        for (EntityItem item : items) {
            // Apply override rating if available
            Rating rating = ratingOverrides.getOrDefault(item.getEntityId(), baseRatings.get(item.getEntityId()));

            int window = getWindowByRating(rating);
            boolean isValid = checkValidity(item, rating);

            item.setWindow(window);
            item.setValid(isValid);
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Rating> extractRatingOverrides(Map<String, Object> scenarioContext) {
        List<EntityRatingChangeDTO> changes = (List<EntityRatingChangeDTO>) scenarioContext.getOrDefault("entityRatingChanges", List.of());

        Map<String, Rating> ratingMap = new HashMap<>();
        for (EntityRatingChangeDTO dto : changes) {
            ratingMap.put(dto.getEntityId(), new Rating(dto.getRating()));
        }
        return ratingMap;
    }



    private int getWindowByRating(Rating rating) {
        return switch (rating.getValue()) {
            case "LOW" -> 4;
            case "MEDIUM" -> 8;
            case "HIGH" -> 12;
            default -> 4;
        };
    }

    private boolean checkValidity(EntityItem item, Rating rating) {
        // Add custom business logic
        return true;
    }

    @Override
    public String getEntityType() {
        return "OURC";
    }
}


