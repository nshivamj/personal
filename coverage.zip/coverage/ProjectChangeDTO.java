package com.portfolio.coverage;

public class ProjectChangeDTO {
    private String projectId;
    private Map<String, Object> changedAttributes;

    public ProjectChangeDTO(String projectId, Map<String, Object> changedAttributes) {
        this.projectId = projectId;
        this.changedAttributes = changedAttributes;
    }

    public String getProjectId() {
        return projectId;
    }

    public Map<String, Object> getChangedAttributes() {
        return changedAttributes;
    }
}









