package com.portfolio.coverage;

@Component
public class OUBPEntityItemEnricher implements EntityItemEnricher {

    @Override
    public List<EntityItem> enrich(List<BaseEntityItem> baseItems, ScenarioContext context) {
        List<EntityItem> result = new ArrayList<>();

        for (BaseEntityItem base : baseItems) {
            EntityItem item = new EntityItem(base);
            item.setWindow(4); // fixed for OUBP

            item.setValid(checkIsValid(base.getItemAttributes()));
            result.add(item);
        }

        return result;
    }

    @Override
    public String getSupportedEntityType() {
        return "OUBP";
    }

    private boolean checkIsValid(Map<String, Object> attributes) {
        // Your specific logic for OUBP
        // For example:
        return attributes.containsKey("finalized") && Boolean.TRUE.equals(attributes.get("finalized"));
    }
}



