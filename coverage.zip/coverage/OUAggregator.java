package com.portfolio.coverage;

public interface OUAggregator {
    boolean supports(EntityType entityType);

    OUCoverageSummary aggregateOuCoverage(String ouId, EntityType entityType, LocalDate period, List<CoverageSummary> entitySummaries);
}





