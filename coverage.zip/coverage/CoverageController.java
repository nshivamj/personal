package com.portfolio.coverage;

@RestController
@RequestMapping("/api/coverage")
public class CoverageController {

    @Autowired
    private CoverageEvaluationService coverageEvaluationService;

    @PostMapping("/evaluate")
    public ResponseEntity<List<OUCoverageSummary>> evaluateCoverage(@RequestBody CoverageRequest request) {
        List<OUCoverageSummary> result = coverageEvaluationService.evaluateCoverage(request);
        return ResponseEntity.ok(result);
    }
}


