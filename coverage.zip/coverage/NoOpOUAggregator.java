package com.portfolio.coverage;

public class NoOpOUAggregator implements OUAggregator {

    @Override
    public boolean supports(EntityType entityType) {
        return EntityType.OUBP.equals(entityType);
    }

    @Override
    public OUCoverageSummary aggregateOuCoverage(String ouId, EntityType entityType, LocalDate period, List<CoverageSummary> entitySummaries) {
        // Default: Treat individual entity summaries as final (no OU roll-up)
        OUCoverageSummary summary = new OUCoverageSummary();
        summary.setOuId(ouId);
        summary.setEntityType(entityType.name());
        summary.setPeriod(period);
        summary.setOuCovered(false); // or based on a rule
        summary.setEntitySummaries(entitySummaries);

        return summary;
    }
}





