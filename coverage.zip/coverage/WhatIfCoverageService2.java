package com.portfolio.coverage;


public class WhatIfCoverageService2 {

    @Autowired private EntityItemBuilderService itemBuilderService;
    @Autowired private EntityItemService itemService;
    @Autowired private CoverageCalculationService calculationService;

    public List<CoverageResult> evaluateWhatIf(ScenarioContext context) {
        List<EntityItem> items = itemBuilderService.buildWithWhatIfChanges(context);

        // Enrich with metadata, rating, etc.
        List<EntityItem> enriched = itemService.enrich(items, context);

        // Calculate coverage
        return calculationService.calculate(enriched);
    }
}
