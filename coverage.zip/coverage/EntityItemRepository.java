package com.portfolio.coverage;

@Repository
public class EntityItemRepository {

    @Autowired private ItemRepository itemRepo; // Contains raw project data
    @Autowired private EntityRepository entityRepo; // Contains OU or entity metadata

    public EntityItem buildEmptyEntityItem(String projectId, String entityId) {
        Item item = itemRepo.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found: " + projectId));

        Entity entity = entityRepo.findById(entityId)
                .orElseThrow(() -> new RuntimeException("Entity not found: " + entityId));

        // Construct EntityItem with minimal data required
        return EntityItem.builder()
                .projectId(projectId)
                .entityId(entityId)
                .entityType(entity.getEntityType())
                .itemAttributes(item.getAttributes()) // item attributes map
                .build();
    }
}


